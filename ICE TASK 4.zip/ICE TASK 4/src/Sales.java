/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author naido
 */

// ****************************************************************
// Sales.java
//
// Reads in and stores sales for each of 5 salespeople. Displays
// sales entered by salesperson id and total sales for all salespeople.
//
// *
import java.util.Scanner;
public class Sales {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        
        System.out.print("Enter the number of salespeople: ");
        int SALESPEOPLE = scan.nextInt();
        
        int[] sales = new int[SALESPEOPLE];
        int sum = 0;
        
        int maxSale = Integer.MIN_VALUE;
        int maxSalePerson = 0;
        
        int minSale = Integer.MAX_VALUE;
        int minSalePerson = 0;
        
        for (int i = 0; i < sales.length; i++) {
            System.out.print("Enter sales for salesperson " + (i + 1) + ": R");
            sales[i] = scan.nextInt();

            if (sales[i] > maxSale) {
                maxSale = sales[i];
                maxSalePerson = i;
            }
            
            if (sales[i] < minSale) {
                minSale = sales[i];
                minSalePerson = i;
            }
        }
        
        System.out.println("\nSalesperson Sales");
        System.out.println("--------------------");
        //sum = 0;
        for (int i = 0; i < sales.length; i++) {
            System.out.println(" " + (i + 1) + ". R" + sales[i]);
            sum += sales[i];
        }
        
        System.out.println("\nTotal sales: R" + sum);
        
        double average = (double) sum / SALESPEOPLE;
        System.out.println("Average sales: R" + average);
        
        System.out.println("Salesperson " + (maxSalePerson + 1) + " has the highest sale with R" + maxSale + ".");
        
        System.out.println("Salesperson " + (minSalePerson + 1 ) + " has the lowest sale with R" + minSale + ".");
        
        System.out.print("\nEnter a value to compare salespeople's sales: R");
        int value = scan.nextInt();
        
        int count = 0;
        System.out.println("\nSalespeople who exceeded the sales value of R" + value + ":");
        for (int i = 0; i < sales.length; i++){
            if (sales[i] > value){
                System.out.println("Salesperson " + (i + 1) + " with sales R" + sales[i]);
                count++;
            }
        }
        System.out.println("Total number of salespeople who exceeded the sales value is " + count);
    }
}
